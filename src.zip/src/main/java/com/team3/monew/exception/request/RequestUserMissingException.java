package com.team3.monew.exception.request;

import com.team3.monew.global.enums.ErrorCode;
import java.util.Map;

public class RequestUserMissingException extends RequestUserException {

  public RequestUserMissingException() {
    super(ErrorCode.REQUEST_USER_MISSING, Map.of("principal", "required"));
  }
}
