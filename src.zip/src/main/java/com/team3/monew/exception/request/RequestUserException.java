package com.team3.monew.exception.request;

import com.team3.monew.global.enums.ErrorCode;
import com.team3.monew.global.exception.BusinessException;
import java.util.Map;

public class RequestUserException extends BusinessException {

  public RequestUserException(ErrorCode errorCode) {
    super(errorCode, Map.of());
  }

  public RequestUserException(ErrorCode errorCode, Map<String, Object> details) {
    super(errorCode, details);
  }
}
