package com.team3.monew.exception.request;

import com.team3.monew.global.enums.ErrorCode;
import java.util.Map;

public class InvalidRequestUserException extends RequestUserException {

  public InvalidRequestUserException(String principal) {
    super(ErrorCode.INVALID_REQUEST_USER, Map.of("principal", principal));
  }
}
